//  Created by Nguyen Thanh Dat on 29/8/22.
//  Copyright © 2022 Nguyen Thanh Dat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface @@CLASSPREFIX@@MemEntry : NSObject

@end
