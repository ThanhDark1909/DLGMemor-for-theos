# DLGMemor-for-theos
you can make DLGMemor tweak in theos withou xcode,
